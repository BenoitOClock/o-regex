# Leçon 5 : Intervalles de caractères

Nous venons de voir comment inclure ou exclure des caractères spécifiques, voyons maintenant comment correspondre avec un intervalle de caractères.

Quand on utilise la notation entre crochets, il est possible d'utilise le `-`pour indiquer un intervalle de caractères. Par exemple, le pattern `[0-6]` correspondrait à n'importe quel chiffre compris entre `0` et `6` et à rien d'autre. Et de la même façon, `[^n-p]` correspondrait à n'importe quel caractères pourvu que ce ne soit pas une lettre comprise entre `n` et `p`.

Il est possible d'utiliser plusieurs intervalles au sein de la même paire de crochets et aussi d'y adjoindre des caractères spécifiques. Par exemple `[A-Za-z0-9_]` correspondra à une lettre majuscule ou minuscule, un chiffre, ou au caractère `_`.

Dans l'exercice suivant vous devez trouver une regex correspondant aux 3 premières lignes. Notez que les intervalles sont sensibles à la casse. `[a-z]` ne correspond qu'aux minuscules et `[A-Z]` qu'aux majuscules.

## exercice

1. match Ana
2. match Bob
3. match Cpc
4. skip aax
5. skip bby
6. skip ccz

**solution**

`[A-B][n-p][a-c]` ou `[^a-c][^a-c][^x-z]`
